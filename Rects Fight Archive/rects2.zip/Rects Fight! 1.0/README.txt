  _____           _         ______ _       _     _   
 |  __ \         | |       |  ____(_)     | |   | |  
 | |__) |___  ___| |_ ___  | |__   _  __ _| |__ | |_ 
 |  _  // _ \/ __| __/ __| |  __| | |/ _` | '_ \| __|
 | | \ \  __/ (__| |_\__ \ | |    | | (_| | | | | |_ 
 |_|  \_\___|\___|\__|___/ |_|    |_|\__, |_| |_|\__|
                                      __/ |          
                                     |___/           

Version 1.0 : SnivyDroid

Run Main.py to Start
WASD to move Player 1 (Blue)
Arrow keys to move Player 2 (Orange)

E to shoot from Player 1 (Blue)
SPACE to shoot from Player 2 (Orange)

TAB to pause 
LSHIFT to Unpause 
ESC to leave

Game Ends when one player dies [After taking three hits]