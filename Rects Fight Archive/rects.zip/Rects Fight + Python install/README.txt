  _____           _         ______ _       _     _   
 |  __ \         | |       |  ____(_)     | |   | |  
 | |__) |___  ___| |_ ___  | |__   _  __ _| |__ | |_ 
 |  _  // _ \/ __| __/ __| |  __| | |/ _` | '_ \| __|
 | | \ \  __/ (__| |_\__ \ | |    | | (_| | | | | |_ 
 |_|  \_\___|\___|\__|___/ |_|    |_|\__, |_| |_|\__|
                                      __/ |          
                                     |___/           

Version 1.1 : SnivyDroid

HOW TO START
1. Run the python installerfile in the install folder
2. On the first screen, deselect the "add launcher" option at the bottom
3. Select the "add PATH" button at the bottom
4. let python install
5. Run the pygameinstaller.bat file in the install folder
6. If the main.py file in the rects fight folder has a icon with a paper and the python logo, skip steps 7-10
7. If it is, go to settings > default apps > choose default apps by file type
8. Scroll down until you see the .py extension
9. Click on the folder and select the option with an icon of a little rocket and the python logo
10. Select that option
11. Go into the rects fight folder and click Main.py

CONTROLS:
WASD to move Player 1 (Blue)
Arrow keys to move Player 2 (Orange)

E to shoot from Player 1 (Blue)
SPACE to shoot from Player 2 (Orange)

TAB to pause 
LSHIFT to Unpause 
ESC to leave

Game Ends when one player dies [After taking three hits]



Changelog 1.1:
- Fixed a bug where bullets kept moving after pause was pressed
- Changed the start screen
- Changed Icon