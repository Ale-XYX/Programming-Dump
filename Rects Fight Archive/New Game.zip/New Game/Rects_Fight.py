if __name__ == '__main__':
    print('CLIENT: Loading Rects Fight V1.7')
    import pygame
    import sys

    sys.path.insert(0, './GAME_DATA')
    import GAME as g

    pygame.init()
    g.TITLE_SCREEN()
    g.MODE_SELECT()
    g.CHARACTER_SELECT()
    while g.g.SUPERLOOP:
        g.GAME()
    
    pygame.quit()

